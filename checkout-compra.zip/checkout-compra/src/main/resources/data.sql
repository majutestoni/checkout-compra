INSERT INTO coupons (id_coupon, cd_coupon, vl_discount, is_freight) VALUES (1, 'CUPOM10', 10.0, false);
INSERT INTO coupons (id_coupon, cd_coupon, vl_discount, is_freight) VALUES (2, 'CUPOMFRETEGRATIS', 0.0, true);
