package com.estudo.checkout_compra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckoutCompraApplicationTests {

	@Test
	void contextLoads() {
	}

}
